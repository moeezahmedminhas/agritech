// import 'package:flutter/material.dart';
// import 'package:cloud_firestore/cloud_firestore.dart';
// import 'package:agritech/models/order.dart' as order;

// class OrderHistoryScreen extends StatefulWidget {
//   const OrderHistoryScreen({super.key});

//   @override
//   State<OrderHistoryScreen> createState() => _OrderHistoryScreenState();
// }

// class _OrderHistoryScreenState extends State<OrderHistoryScreen> {
//   DateTime selectedDate = DateTime.now(); // Initialize with the current date
//   List<order.Order> orders = [];

//   Future<void> _selectDate(BuildContext context) async {
//     final DateTime? picked = await showDatePicker(
//       context: context,
//       initialDate: selectedDate,
//       firstDate: DateTime(2000),
//       lastDate: DateTime(2101),
//     );

//     if (picked != null && picked != selectedDate) {
//       setState(() {
//         selectedDate = picked;
//         fetchOrdersForSelectedDate();
//       });
//     }
//   }

//   Future<void> fetchOrdersForSelectedDate() async {
//     final startOfDay =
//         DateTime(selectedDate.year, selectedDate.month, selectedDate.day);
//     final endOfDay = startOfDay.add(const Duration(days: 1));

//     final querySnapshot = await FirebaseFirestore.instance
//         .collection('orders')
//         .where('orderDate', isGreaterThanOrEqualTo: startOfDay)
//         .where('orderDate', isLessThan: endOfDay)
//         .get();

//     final filteredOrders = querySnapshot.docs.map((doc) {
//       return order.Order.fromJson(doc.data());
//     }).toList();

//     setState(() {
//       orders = filteredOrders;
//     });
//   }

//   @override
//   void initState() {
//     super.initState();
//     fetchOrdersForSelectedDate();
//   }

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: Text('Order'),
//       ),
//       body: Column(
//         children: [
//           SizedBox(
//             height: 20,
//           ),
//           Text(
//             'Select a Date:',
//             style: TextStyle(fontSize: 18),
//           ),
//           TextButton(
//             onPressed: () => _selectDate(context),
//             child: Text(
//               "${selectedDate.toLocal()}".split(' ')[0],
//               style: TextStyle(
//                 fontSize: 55,
//                 fontWeight: FontWeight.bold,
//                 color: Colors.blue,
//               ),
//             ),
//           ),
//           SizedBox(
//             height: 20,
//           ),
//           Expanded(
//             child: ListView.builder(
//               itemCount: orders.length,
//               itemBuilder: (context, index) {
//                 return ListTile(
//                   title: Text('Order ID: ${orders[index].id}'),
//                   subtitle: Text(
//                       'Total Amount: \$${orders[index].totalAmount.toStringAsFixed(2)}'),
//                 );
//               },
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
