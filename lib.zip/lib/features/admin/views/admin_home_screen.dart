import 'package:flutter/material.dart';

class AdminHomeScreen extends StatelessWidget {
  const AdminHomeScreen({super.key});
  static const routeName = 'admin-home';
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}
