import 'package:flutter/material.dart';

const primaryColor = Color(0xff00B251);
const grayColor = Color(0xff858585);
const lightGrayColor = Color(0xffBFBFBF);
